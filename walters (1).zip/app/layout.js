
export const metadata = {
  title: "Donis Car Detailing",
  description: "Mobile auto detailing service.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
