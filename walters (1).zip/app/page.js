
export default function HomePage() {
  return (
    <div style={{padding:40}}>
      <h1>Donis Car Detailing</h1>
      <p>Your full English site will be added here next.</p>
    </div>
  );
}
